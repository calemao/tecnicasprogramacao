/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Christian Amsberg Janner <janner.chris15@outlook.com>
@date 04/03/2024
@brief Class Ex02
public class Ex02 {
/*
 *
 * 
 */

package capitulo3.exercicios.exercicio.Christian;

public class Ex02 {
    public static void main(String[] args) {
        double x = 3.5;
        double y = 4.64;
        
        System.out.println("Valor de X: " + x);
        System.out.println("Valor de Y: " + y);
        
    }
}


