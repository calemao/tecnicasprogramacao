/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package capitulo3.exercicios.exercicio.Christian;

/**
 *
 * @author Christian Amsberg Janner <janner.chris15@outlook.com>
 */
public class Ex01 {

    public static void main(String[] args) {
        System.out.println("Christian Amsberg Janner");
    }
}
