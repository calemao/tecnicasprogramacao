/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package capitulo3.exercicios.exercicio.Christian;

/**
 *
 * @author Christian Amsberg Janner <janner.chris15@outlook.com>
@date 04/03/2024
@brief Class Ex03
public class Ex03 {
/*
 *
 * 
 */

public class Ex03 {
    public static void main(String[] args) {
        int x,y,z;
        x=3;
        y=4;
        z=2;
        System.out.println(x*y/z);
    }
}


